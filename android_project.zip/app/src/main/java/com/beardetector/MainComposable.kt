package com.beardetector

import androidx.compose.runtime.Composable
import androidx.navigation.compose.rememberNavController
import com.beardetector.ui.BearDetectorNavGraph
import com.beardetector.ui.theme.BearDetectorTheme
import com.beardetector.ui.viewmodel.MainViewModel
import com.beardetector.ui.viewmodel.SettingsViewModel

@Composable
fun MainComposable(
    mainViewModel: MainViewModel,
    settingsViewModel: SettingsViewModel,
    onStartServer: () -> Unit,
    onStopServer: () -> Unit
) {
    BearDetectorTheme {
        BearDetectorNavGraph(
            navController     = rememberNavController(),
            mainViewModel     = mainViewModel,
            settingsViewModel = settingsViewModel,
            onStartServer     = onStartServer,
            onStopServer      = onStopServer
        )
    }
}
