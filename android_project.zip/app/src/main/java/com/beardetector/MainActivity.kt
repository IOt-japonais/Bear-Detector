package com.beardetector

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import com.beardetector.data.database.DetectionEvent
import com.beardetector.service.CleanupWorker
import com.beardetector.service.ImageReceiverServer
import com.beardetector.ui.viewmodel.MainViewModel
import com.beardetector.ui.viewmodel.SettingsViewModel
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private val TAG = "MainActivity"
    private val PERM_REQUEST_CODE = 100

    private lateinit var mainViewModel: MainViewModel
    private lateinit var settingsViewModel: SettingsViewModel

    private var boundService: ImageReceiverServer? = null
    private var serviceBound = false

    // ── Service connection ────────────────────────────────────
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            val binder = service as ImageReceiverServer.LocalBinder
            boundService = binder.getService()
            serviceBound = true
            Log.d(TAG, "ImageReceiverServer bound")

            boundService?.setStatusListener(object : ImageReceiverServer.StatusListener {
                override fun onStatus(message: String) {
                    mainViewModel.appendLog(message)
                    mainViewModel.setServerRunning(boundService?.isServerRunning ?: false)
                }
                override fun onNewDetection(event: DetectionEvent) {
                    // Room LiveData propagates the change automatically
                }
            })

            mainViewModel.setServerRunning(boundService?.isServerRunning ?: false)
            mainViewModel.setServerIp(ImageReceiverServer.getHotspotIp())
        }

        override fun onServiceDisconnected(name: ComponentName) {
            serviceBound = false
            boundService = null
            mainViewModel.setServerRunning(false)
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mainViewModel     = ViewModelProvider(this)[MainViewModel::class.java]
        settingsViewModel = ViewModelProvider(this)[SettingsViewModel::class.java]

        requestPermissions()
        startAndBindService()
        scheduleCleanup()

        setContent {
            MainComposable(
                mainViewModel     = mainViewModel,
                settingsViewModel = settingsViewModel,
                onStartServer     = { handleStartServer() },
                onStopServer      = { handleStopServer() }
            )
        }
    }

    // ── Server control ────────────────────────────────────────

    private fun handleStartServer() {
        boundService?.startServer()
        mainViewModel.setServerRunning(boundService?.isServerRunning ?: false)
        mainViewModel.setServerIp(ImageReceiverServer.getHotspotIp())
    }

    private fun handleStopServer() {
        boundService?.stopServer()
        mainViewModel.setServerRunning(false)
    }

    // ── Internal helpers ──────────────────────────────────────

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    PERM_REQUEST_CODE
                )
            }
        }
    }

    private fun startAndBindService() {
        val intent = Intent(this, ImageReceiverServer::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun scheduleCleanup() {
        val work = PeriodicWorkRequest.Builder(
            CleanupWorker::class.java, 1, TimeUnit.DAYS
        ).addTag("cleanup").build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "cleanup_work",
            ExistingPeriodicWorkPolicy.KEEP,
            work
        )
    }

    override fun onDestroy() {
        if (serviceBound) {
            unbindService(serviceConnection)
            serviceBound = false
        }
        super.onDestroy()
    }
}
