package com.beardetector.service;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.beardetector.data.repository.DetectionRepository;
import com.beardetector.data.repository.SettingsRepository;
import com.beardetector.utils.ImageStorageUtil;

import java.util.concurrent.TimeUnit;

public class CleanupWorker extends Worker {

    private static final String TAG = "CleanupWorker";

    public CleanupWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        SettingsRepository settings = SettingsRepository.getInstance(ctx);
        DetectionRepository repo = DetectionRepository.getInstance(ctx);

        int days = settings.getAutoDeleteDays();
        if (days <= 0) return Result.success();

        long cutoff = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(days);

        // Delete old DB records
        repo.deleteOldEvents(cutoff, count ->
                Log.d(TAG, "Deleted " + count + " old DB events"));

        // Delete old image files
        int filesDeleted = ImageStorageUtil.deleteImagesOlderThan(ctx, cutoff);
        Log.d(TAG, "Deleted " + filesDeleted + " old image files (cutoff=" + days + " days)");

        return Result.success();
    }
}
