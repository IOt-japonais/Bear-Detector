package com.beardetector.service;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import com.beardetector.data.database.DetectionEvent;
import com.beardetector.data.repository.DetectionRepository;
import com.beardetector.data.repository.SettingsRepository;
import com.beardetector.utils.ImageStorageUtil;
import com.beardetector.utils.NotificationHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Foreground service that runs a minimal HTTP server on port 8080.
 *
 * Designed for the Android-hotspot architecture:
 *   • Android phone enables its mobile hotspot.
 *   • ESP32-CAM connects to that hotspot as a Wi-Fi STA client.
 *   • ESP32-CAM sends: POST /upload  (Content-Type: image/jpeg, raw body).
 *   • This service receives the JPEG, saves it, runs AI, fires notifications.
 *   • Android's 4G data path is completely separate — Anthropic calls work fine.
 *
 * The server listens on 0.0.0.0:8080, so it accepts connections on
 * every interface including the hotspot one (typically 192.168.43.1).
 *
 * Start/stop is controlled from the UI via startServer() / stopServer().
 */
public class ImageReceiverServer extends Service {

    private static final String TAG      = "ImageReceiverServer";
    public  static final int    PORT     = 8080;
    private static final int    NOTIF_ID = 1;

    // ── Binder ───────────────────────────────────────────────
    public class LocalBinder extends Binder {
        public ImageReceiverServer getService() { return ImageReceiverServer.this; }
    }
    private final LocalBinder binder = new LocalBinder();

    // ── State ────────────────────────────────────────────────
    private ServerSocket     serverSocket;
    private ExecutorService  acceptPool;
    private volatile boolean running = false;

    private DetectionRepository repository;
    private SettingsRepository  settings;
    private StatusListener      listener;

    // ── Listener interface ────────────────────────────────────
    public interface StatusListener {
        void onStatus(String message);
        void onNewDetection(DetectionEvent event);
    }

    public void setStatusListener(StatusListener l) { this.listener = l; }

    // ── Lifecycle ────────────────────────────────────────────
    @Override
    public void onCreate() {
        super.onCreate();
        repository = DetectionRepository.getInstance(getApplication());
        settings   = SettingsRepository.getInstance(getApplication());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID,
                NotificationHelper.buildStoppedNotification(this));
        return START_STICKY;
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onDestroy() {
        stopServer();
        super.onDestroy();
    }

    // ── Public API ────────────────────────────────────────────

    public boolean isServerRunning() { return running; }

    /**
     * Start the HTTP server on PORT.
     * Binds to 0.0.0.0 so it accepts on all interfaces,
     * including the hotspot interface (192.168.43.x).
     * Safe to call multiple times.
     */
    public void startServer() {
        if (running) {
            log("Server already running on port " + PORT);
            return;
        }
        acceptPool = Executors.newCachedThreadPool();
        acceptPool.execute(this::acceptLoop);
    }

    /** Stop the HTTP server. The foreground service itself keeps running. */
    public void stopServer() {
        running = false;
        try {
            if (serverSocket != null && !serverSocket.isClosed())
                serverSocket.close();
        } catch (IOException ignored) {}
        if (acceptPool != null) {
            acceptPool.shutdownNow();
            acceptPool = null;
        }
        log("Server stopped.");
        startForeground(NOTIF_ID,
                NotificationHelper.buildStoppedNotification(this));
    }

    // ── Accept loop ──────────────────────────────────────────

    private void acceptLoop() {
        try {
            serverSocket = new ServerSocket(PORT);
            serverSocket.setSoTimeout(0);
            running = true;

            startForeground(NOTIF_ID,
                    NotificationHelper.buildServerNotification(this, PORT));

            log("HTTP server listening on port " + PORT
                    + " | hotspot gateway: " + getHotspotIp());

            while (running) {
                try {
                    Socket client = serverSocket.accept();
                    acceptPool.execute(() -> handleClient(client));
                } catch (IOException e) {
                    if (running) log("Accept error: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            log("Cannot bind port " + PORT + ": " + e.getMessage());
            running = false;
            startForeground(NOTIF_ID,
                    NotificationHelper.buildStoppedNotification(this));
        }
    }

    // ── Per-connection handler ────────────────────────────────

    private void handleClient(Socket client) {
        try {
            client.setSoTimeout(15_000);
            InputStream  in  = new BufferedInputStream(client.getInputStream());
            OutputStream out = client.getOutputStream();

            String requestLine = readLine(in);
            if (requestLine == null || requestLine.isEmpty()) {
                sendResponse(out, 400, "Bad Request", "Empty request");
                return;
            }
            log("← " + requestLine + "  from " + client.getInetAddress().getHostAddress());

            String[] parts  = requestLine.split(" ");
            String   method = parts.length > 0 ? parts[0] : "";
            String   path   = parts.length > 1 ? parts[1] : "/";

            int    contentLength = -1;
            String contentType   = "";
            String line;
            while (!(line = readLine(in)).isEmpty()) {
                String lower = line.toLowerCase();
                if (lower.startsWith("content-length:")) {
                    try { contentLength = Integer.parseInt(line.split(":", 2)[1].trim()); }
                    catch (NumberFormatException ignored) {}
                } else if (lower.startsWith("content-type:")) {
                    contentType = line.split(":", 2)[1].trim().toLowerCase();
                }
            }

            if ("POST".equalsIgnoreCase(method) && "/upload".equals(path)) {
                handleUpload(in, out, contentLength, contentType);
            } else if ("GET".equalsIgnoreCase(method) && "/ping".equals(path)) {
                sendResponse(out, 200, "OK", "pong");
            } else {
                sendResponse(out, 404, "Not Found", path);
            }

        } catch (IOException e) {
            Log.e(TAG, "Client error: " + e.getMessage());
        } finally {
            try { client.close(); } catch (IOException ignored) {}
        }
    }

    // ── /upload ───────────────────────────────────────────────

    private void handleUpload(InputStream in, OutputStream out,
                              int contentLength, String contentType) throws IOException {

        if (!contentType.contains("jpeg") && !contentType.contains("octet-stream")) {
            sendResponse(out, 415, "Unsupported Media Type", "Expected image/jpeg");
            return;
        }
        if (contentLength <= 0) {
            sendResponse(out, 411, "Length Required", "Content-Length missing");
            return;
        }
        if (contentLength > 5_000_000) {
            sendResponse(out, 413, "Payload Too Large", "Max 5 MB");
            return;
        }

        byte[] imageBytes = readExact(in, contentLength);
        if (imageBytes == null) {
            sendResponse(out, 500, "Read Error", "Body read failed");
            return;
        }

        log("← Received " + imageBytes.length + " bytes JPEG");
        // Respond immediately so ESP32 can disconnect and go to sleep
        sendResponse(out, 200, "OK", "Received");

        byte[] img = imageBytes;
        new Thread(() -> processImage(img)).start();
    }

    // ── Image processing ──────────────────────────────────────
    private void processImage(byte[] jpegBytes) {
        // Validate JPEG: must start with FF D8 and end with FF D9
        if (jpegBytes.length < 4
                || (jpegBytes[0] & 0xFF) != 0xFF
                || (jpegBytes[1] & 0xFF) != 0xD8
                || (jpegBytes[jpegBytes.length - 2] & 0xFF) != 0xFF
                || (jpegBytes[jpegBytes.length - 1] & 0xFF) != 0xD9) {
            log("Invalid JPEG: " + jpegBytes.length + " bytes, "
                    + "header=" + String.format("%02X%02X", jpegBytes[0] & 0xFF, jpegBytes[1] & 0xFF)
                    + " footer=" + String.format("%02X%02X",
                    jpegBytes[jpegBytes.length - 2] & 0xFF,
                    jpegBytes[jpegBytes.length - 1] & 0xFF));
            return;
        }
        log("JPEG OK: " + jpegBytes.length + " bytes");

        // 1. Save
        String imagePath = ImageStorageUtil.saveImage(getApplicationContext(), jpegBytes);
        if (imagePath == null) { log("Save failed."); return; }
        log("Saved: " + imagePath);

        // 2. AI classification via Anthropic Vision
        String apiKey = settings.getAnthropicApiKey();
        if (apiKey == null || apiKey.isEmpty()) {
            log("No API key → saving event without AI");
            saveEvent("unknown", 0, false, "No API key configured", imagePath);
            return;
        }

        classifyWithAnthropic(jpegBytes, apiKey, imagePath);
    }
    // ── Anthropic Vision API call ─────────────────────────────

    private void classifyWithAnthropic(byte[] jpegBytes, String apiKey,
                                       String imagePath) {
        try {
            log("AI [1/5] encoding " + jpegBytes.length + " bytes as base64");
            String b64 = android.util.Base64.encodeToString(jpegBytes,
                    android.util.Base64.NO_WRAP);

            log("AI [2/5] building JSON body");
            JSONObject imageSource = new JSONObject();
            imageSource.put("type", "base64");
            imageSource.put("media_type", "image/jpeg");
            imageSource.put("data", b64);

            JSONObject imagePart = new JSONObject();
            imagePart.put("type", "image");
            imagePart.put("source", imageSource);

            JSONObject textPart = new JSONObject();
            textPart.put("type", "text");
            textPart.put("text",
                    "You are a wildlife camera classifier. " +
                            "Identify the main subject of this image. " +
                            "Reply ONLY with valid JSON, no markdown: " +
                            "{\"animal\":\"bear|deer|human|dog|boar|empty|other\"," +
                            "\"confidence\":0-100," +
                            "\"danger\":true|false," +
                            "\"description\":\"one sentence\"}");

            JSONArray content = new JSONArray();
            content.put(imagePart);
            content.put(textPart);

            JSONObject message = new JSONObject();
            message.put("role", "user");
            message.put("content", content);

            JSONObject body = new JSONObject();
            body.put("model", "claude-haiku-4-5");
            body.put("max_tokens", 150);
            body.put("messages", new JSONArray().put(message));

            String bodyStr = body.toString();
            log("AI [3/5] connecting to Anthropic API (body=" + bodyStr.length() + " bytes)");

            okhttp3.OkHttpClient client = new okhttp3.OkHttpClient.Builder()
                    .connectTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                    .build();

            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url("https://api.anthropic.com/v1/messages")
                    .post(okhttp3.RequestBody.create(
                            bodyStr,
                            okhttp3.MediaType.get("application/json; charset=utf-8")))
                    .addHeader("x-api-key", apiKey)
                    .addHeader("anthropic-version", "2023-06-01")
                    .build();

            log("AI [4/5] waiting for response...");
            try (okhttp3.Response resp = client.newCall(request).execute()) {
                int    code    = resp.code();
                String respStr = resp.body() != null ? resp.body().string() : "";

                log("AI [5/5] HTTP " + code);
                if (code != 200) {
                    log("Anthropic error " + code + ": " + respStr);
                    Log.e(TAG, "=== ANTHROPIC 400 BODY ===\n" + respStr);
                    saveEvent("unknown", 0, false, "API error " + code, imagePath);
                    return;
                }

                String aiContent = new JSONObject(respStr)
                        .getJSONArray("content")
                        .getJSONObject(0)
                        .getString("text")
                        .trim();

                if (aiContent.startsWith("```")) {
                    aiContent = aiContent
                            .replaceAll("(?s)```[a-z]*\\n?", "")
                            .replace("```", "")
                            .trim();
                }

                JSONObject result   = new JSONObject(aiContent);
                String  animal      = result.optString("animal", "unknown");
                int     confidence  = result.optInt("confidence", 0);
                boolean danger      = result.optBoolean("danger", false);
                String  description = result.optString("description", "");

                log("AI → " + animal + " " + confidence + "% danger=" + danger);
                saveEvent(animal, confidence, danger, description, imagePath);
            }

        } catch (Exception e) {
            Log.e(TAG, "AI call failed: " + e.getClass().getSimpleName() + ": " + e.getMessage(), e);
            log("AI error [" + e.getClass().getSimpleName() + "]: " + e.getMessage());
            saveEvent("unknown", 0, false, "AI exception: " + e.getMessage(), imagePath);
        }
    }
    /**
     * Opens an HttpURLConnection bound to the mobile-data (cellular) network.
     * This is necessary when the Android hotspot is active, because the OS
     * default route points at the hotspot interface rather than the cellular
     * interface, so plain openConnection() cannot reach the internet.
     *
     * Returns null if no suitable network is found (caller should fall back).
     */
    private java.net.HttpURLConnection openOnMobileNetwork(java.net.URL url) {
        try {
            ConnectivityManager cm =
                    (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return null;

            Network[] networks = cm.getAllNetworks();
            for (Network net : networks) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(net);
                if (caps == null) continue;
                boolean hasMobile   = caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);
                boolean hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
                boolean notVpn      = !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
                if (hasMobile && hasInternet && notVpn) {
                    log("AI using cellular network for API call");
                    return (java.net.HttpURLConnection) net.openConnection(url);
                }
            }
            log("AI no cellular network found, using default route");
        } catch (Exception e) {
            Log.w(TAG, "openOnMobileNetwork failed: " + e.getMessage());
        }
        return null;
    }

    private void saveEvent(String animal, int confidence, boolean danger,
                           String description, String imagePath) {
        DetectionEvent ev = new DetectionEvent();
        ev.timestamp      = System.currentTimeMillis();
        ev.animal         = animal;
        ev.confidence     = confidence;
        ev.danger         = danger;
        ev.description    = description;
        ev.imagePath      = imagePath;

        repository.insert(ev, id -> {
            ev.id = id;
            if ("bear".equals(animal) && confidence >= 60)
                NotificationHelper.postBearDetectedNotification(getApplicationContext(), ev);
            if (listener != null) listener.onNewDetection(ev);
            log("Event saved: " + animal + " " + confidence + "%");
        });
    }

    // ── Helpers ───────────────────────────────────────────────

    public static String getHotspotIp() {
        try {
            for (NetworkInterface iface :
                    Collections.list(NetworkInterface.getNetworkInterfaces())) {
                String name = iface.getName().toLowerCase();
                if (!name.startsWith("wlan") && !name.startsWith("ap")
                        && !name.startsWith("swlan")) continue;
                for (InetAddress addr : Collections.list(iface.getInetAddresses())) {
                    if (!addr.isLoopbackAddress() && addr instanceof Inet4Address)
                        return addr.getHostAddress();
                }
            }
            for (NetworkInterface iface :
                    Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress addr : Collections.list(iface.getInetAddresses())) {
                    if (!addr.isLoopbackAddress() && addr instanceof Inet4Address)
                        return addr.getHostAddress();
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "getHotspotIp failed", e);
        }
        return "unknown";
    }

    private void sendResponse(OutputStream out, int code, String status, String body)
            throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        String h = "HTTP/1.1 " + code + " " + status + "\r\n"
                + "Content-Type: text/plain\r\n"
                + "Content-Length: " + b.length + "\r\n"
                + "Connection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.UTF_8));
        out.write(b);
        out.flush();
    }

    private String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
        }
        return sb.toString();
    }

    private byte[] readExact(InputStream in, int length) {
        try {
            byte[] buf = new byte[length];
            new DataInputStream(in).readFully(buf);
            return buf;
        } catch (IOException e) {
            Log.e(TAG, "readExact failed: " + e.getMessage());
            return null;
        }
    }

    private byte[] drainStream(InputStream in) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) != -1) baos.write(buf, 0, n);
        return baos.toByteArray();
    }

    private void log(String msg) {
        Log.d(TAG, msg);
        if (listener != null) listener.onStatus(msg);
    }
}
