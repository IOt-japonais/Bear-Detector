package com.beardetector.data.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.beardetector.data.database.AppDatabase;
import com.beardetector.data.database.DetectionDao;
import com.beardetector.data.database.DetectionEvent;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DetectionRepository {

    private static volatile DetectionRepository INSTANCE;

    private final DetectionDao dao;
    private final ExecutorService executor;

    private DetectionRepository(Context context) {
        AppDatabase db = AppDatabase.getInstance(context);
        this.dao = db.detectionDao();
        this.executor = Executors.newFixedThreadPool(2);
    }

    public static DetectionRepository getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (DetectionRepository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new DetectionRepository(context.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    public void insert(DetectionEvent event, InsertCallback callback) {
        executor.execute(() -> {
            long id = dao.insert(event);
            if (callback != null) callback.onInserted(id);
        });
    }

    public void delete(DetectionEvent event) {
        executor.execute(() -> dao.delete(event));
    }

    public void deleteOldEvents(long cutoffTimestamp, DeleteOldCallback callback) {
        executor.execute(() -> {
            int deleted = dao.deleteOldEvents(cutoffTimestamp);
            if (callback != null) callback.onDeleted(deleted);
        });
    }

    public LiveData<List<DetectionEvent>> getAllEvents() {
        return dao.getAllEvents();
    }

    public LiveData<List<DetectionEvent>> getBearEvents() {
        return dao.getBearEvents();
    }

    public void getRecentEvents(int limit, RecentCallback callback) {
        executor.execute(() -> {
            List<DetectionEvent> events = dao.getRecentEvents(limit);
            if (callback != null) callback.onResult(events);
        });
    }

    public interface InsertCallback {
        void onInserted(long id);
    }

    public interface DeleteOldCallback {
        void onDeleted(int count);
    }

    public interface RecentCallback {
        void onResult(List<DetectionEvent> events);
    }
}
