package com.beardetector.data.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface DetectionDao {

    @Insert
    long insert(DetectionEvent event);

    @Update
    void update(DetectionEvent event);

    @Delete
    void delete(DetectionEvent event);

    @Query("SELECT * FROM detection_events ORDER BY timestamp DESC")
    LiveData<List<DetectionEvent>> getAllEvents();

    @Query("SELECT * FROM detection_events ORDER BY timestamp DESC")
    List<DetectionEvent> getAllEventsSync();

    @Query("SELECT * FROM detection_events WHERE id = :id")
    DetectionEvent getEventById(long id);

    @Query("SELECT * FROM detection_events WHERE animal = 'bear' ORDER BY timestamp DESC")
    LiveData<List<DetectionEvent>> getBearEvents();

    @Query("DELETE FROM detection_events WHERE timestamp < :cutoffTimestamp")
    int deleteOldEvents(long cutoffTimestamp);

    @Query("SELECT COUNT(*) FROM detection_events")
    int getTotalCount();

    @Query("SELECT COUNT(*) FROM detection_events WHERE animal = 'bear'")
    int getBearCount();

    @Query("SELECT * FROM detection_events ORDER BY timestamp DESC LIMIT :limit")
    List<DetectionEvent> getRecentEvents(int limit);
}
