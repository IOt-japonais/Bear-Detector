package com.beardetector.data.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "detection_events")
public class DetectionEvent {

    @PrimaryKey(autoGenerate = true)
    public long id;

    public long timestamp;
    public String imagePath;
    public String animal;       // bear|human|deer|dog|boar|other|empty
    public int confidence;
    public boolean danger;
    public String description;
    public boolean notified;    // was a notification sent?
    public float diffPercentage; // image difference that triggered analysis

    public DetectionEvent() {}

    public DetectionEvent(long timestamp, String imagePath, String animal,
                          int confidence, boolean danger, String description,
                          boolean notified, float diffPercentage) {
        this.timestamp = timestamp;
        this.imagePath = imagePath;
        this.animal = animal;
        this.confidence = confidence;
        this.danger = danger;
        this.description = description;
        this.notified = notified;
        this.diffPercentage = diffPercentage;
    }
}
