package com.beardetector.data.repository;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;

public class SettingsRepository {

    private static final String TAG        = "SettingsRepository";
    private static final String PREFS_FILE = "bear_detector_prefs";

    // Keys
    public static final String KEY_ANTHROPIC_API_KEY = "anthropic_api_key";
    public static final String KEY_AUTO_DELETE_DAYS  = "auto_delete_days";
    public static final String KEY_HOTSPOT_SSID      = "hotspot_ssid";
    public static final String KEY_HOTSPOT_PASS      = "hotspot_pass";

    // Defaults
    public static final float DEFAULT_DIFF_THRESHOLD   = 15.0f;
    public static final int   DEFAULT_AUTO_DELETE_DAYS = 30;

    private static volatile SettingsRepository INSTANCE;
    private final SharedPreferences prefs;

    private SettingsRepository(Context context) {
        SharedPreferences tmp;
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            tmp = EncryptedSharedPreferences.create(
                    context,
                    PREFS_FILE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (GeneralSecurityException | IOException e) {
            Log.e(TAG, "Failed to create EncryptedSharedPreferences, falling back to plain", e);
            tmp = context.getSharedPreferences(PREFS_FILE + "_plain", Context.MODE_PRIVATE);
        }
        this.prefs = tmp;
    }

    public static SettingsRepository getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SettingsRepository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new SettingsRepository(context.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    public String getAnthropicApiKey() { return prefs.getString(KEY_ANTHROPIC_API_KEY, ""); }
    public void   setAnthropicApiKey(String key) { prefs.edit().putString(KEY_ANTHROPIC_API_KEY, key).apply(); }


    public int  getAutoDeleteDays() { return prefs.getInt(KEY_AUTO_DELETE_DAYS, DEFAULT_AUTO_DELETE_DAYS); }
    public void setAutoDeleteDays(int days) { prefs.edit().putInt(KEY_AUTO_DELETE_DAYS, days).apply(); }

    public String getHotspotSsid() { return prefs.getString(KEY_HOTSPOT_SSID, ""); }
    public void   setHotspotSsid(String ssid) { prefs.edit().putString(KEY_HOTSPOT_SSID, ssid).apply(); }

    public String getHotspotPass() { return prefs.getString(KEY_HOTSPOT_PASS, ""); }
    public void   setHotspotPass(String pass) { prefs.edit().putString(KEY_HOTSPOT_PASS, pass).apply(); }

    public boolean hasApiKey() {
        String key = getAnthropicApiKey();
        return key != null && !key.trim().isEmpty();
    }
}
