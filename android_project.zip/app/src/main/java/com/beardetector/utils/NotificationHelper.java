package com.beardetector.utils;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.beardetector.BearDetectorApp;
import com.beardetector.MainActivity;
import com.beardetector.R;
import com.beardetector.data.database.DetectionEvent;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class NotificationHelper {

    private static final String TAG = "NotificationHelper";
    private static final AtomicInteger NOTIF_COUNTER = new AtomicInteger(1000);

    /**
     * Posts a high-priority bear detection notification.
     */
    public static void postBearDetectedNotification(Context context, DetectionEvent event) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;

        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra("open_history", true);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                (int) event.id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String time = new SimpleDateFormat("HH:mm", Locale.getDefault())
                .format(new Date(event.timestamp));

        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                context, BearDetectorApp.CHANNEL_ID_BEAR_ALERT)
                .setSmallIcon(R.drawable.ic_bear_notification)
                .setContentTitle("⚠ Bear Detected")
                .setContentText("Confidence: " + event.confidence + "% · Time: " + time)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("Confidence: " + event.confidence + "%\n" +
                                 "Time: " + time + "\n" +
                                 "Details: " + event.description))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

        if (event.imagePath != null) {
            Bitmap thumbnail = loadThumbnail(event.imagePath);
            if (thumbnail != null) {
                builder.setLargeIcon(thumbnail);
                builder.setStyle(new NotificationCompat.BigPictureStyle()
                        .bigPicture(thumbnail)
                        .bigLargeIcon((Bitmap) null)
                        .setSummaryText("Confidence: " + event.confidence + "% · Time: " + time));
            }
        }

        manager.notify(NOTIF_COUNTER.getAndIncrement(), builder.build());
        Log.d(TAG, "Bear detection notification posted for event id=" + event.id);
    }

    private static Bitmap loadThumbnail(String imagePath) {
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 4;
            return BitmapFactory.decodeFile(imagePath, opts);
        } catch (Exception e) {
            Log.e(TAG, "Failed to load thumbnail from " + imagePath, e);
            return null;
        }
    }

    /**
     * Foreground notification shown while the HTTP server is actively listening.
     */
    public static Notification buildServerNotification(Context context, int port) {
        PendingIntent pi = mainActivityIntent(context);
        return new NotificationCompat.Builder(context, BearDetectorApp.CHANNEL_ID_SERVER)
                .setSmallIcon(R.drawable.ic_bear_notification)
                .setContentTitle("Bear Detector Active")
                .setContentText("Listening on port " + port)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    /**
     * Foreground notification shown when the service is running but the server is stopped.
     */
    public static Notification buildStoppedNotification(Context context) {
        PendingIntent pi = mainActivityIntent(context);
        return new NotificationCompat.Builder(context, BearDetectorApp.CHANNEL_ID_SERVER)
                .setSmallIcon(R.drawable.ic_bear_notification)
                .setContentTitle("Bear Detector")
                .setContentText("Server stopped — tap to open app")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    private static PendingIntent mainActivityIntent(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);
    }
}
