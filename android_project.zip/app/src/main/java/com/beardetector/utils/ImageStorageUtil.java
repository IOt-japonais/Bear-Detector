package com.beardetector.utils;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ImageStorageUtil {

    private static final String TAG = "ImageStorageUtil";
    private static final String IMAGE_DIR = "detections";

    /**
     * Saves a JPEG byte array to the app's private files directory.
     * @return Absolute path of the saved file, or null on failure.
     */
    public static String saveImage(Context context, byte[] imageBytes) {
        File dir = getImageDir(context);
        if (!dir.exists() && !dir.mkdirs()) {
            Log.e(TAG, "Failed to create image directory");
            return null;
        }

        String filename = "detection_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date()) +
                ".jpg";
        File file = new File(dir, filename);

        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(imageBytes);
            fos.flush();
            Log.d(TAG, "Image saved: " + file.getAbsolutePath());
            return file.getAbsolutePath();
        } catch (IOException e) {
            Log.e(TAG, "Failed to save image: " + e.getMessage(), e);
            return null;
        }
    }

    public static File getImageDir(Context context) {
        return new File(context.getFilesDir(), IMAGE_DIR);
    }

    public static boolean deleteImage(String path) {
        if (path == null) return false;
        File file = new File(path);
        return file.exists() && file.delete();
    }

    /**
     * Deletes all images older than the given timestamp.
     */
    public static int deleteImagesOlderThan(Context context, long cutoffTimestamp) {
        File dir = getImageDir(context);
        if (!dir.exists()) return 0;

        int deleted = 0;
        File[] files = dir.listFiles();
        if (files == null) return 0;

        for (File file : files) {
            if (file.lastModified() < cutoffTimestamp) {
                if (file.delete()) {
                    deleted++;
                }
            }
        }
        Log.d(TAG, "Deleted " + deleted + " old images");
        return deleted;
    }
}
