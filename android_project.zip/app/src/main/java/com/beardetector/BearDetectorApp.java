package com.beardetector;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class BearDetectorApp extends Application {

    public static final String CHANNEL_ID_BEAR_ALERT = "bear_alert_channel";
    public static final String CHANNEL_ID_SERVER = "server_status_channel";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();
    }

    private void createNotificationChannels() {
        NotificationManager manager = getSystemService(NotificationManager.class);

        // Bear Alert Channel - HIGH priority
        NotificationChannel bearChannel = new NotificationChannel(
                CHANNEL_ID_BEAR_ALERT,
                "Bear Detection Alerts",
                NotificationManager.IMPORTANCE_HIGH
        );
        bearChannel.setDescription("High-priority alerts when a bear is detected");
        bearChannel.enableLights(true);
        bearChannel.enableVibration(true);
        bearChannel.setShowBadge(true);
        manager.createNotificationChannel(bearChannel);

        // Server Status Channel - LOW priority
        NotificationChannel serverChannel = new NotificationChannel(
                CHANNEL_ID_SERVER,
                "Server Status",
                NotificationManager.IMPORTANCE_LOW
        );
        serverChannel.setDescription("HTTP server running status");
        manager.createNotificationChannel(serverChannel);
    }
}
