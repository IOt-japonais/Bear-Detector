package com.beardetector.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.beardetector.data.database.DetectionEvent
import com.beardetector.ui.theme.*
import com.beardetector.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel = viewModel(),
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val serverRunning by viewModel.isServerRunning().observeAsState(false)
    val lastLog       by viewModel.getLastLogMessage().observeAsState("")
    val allEvents     by viewModel.getAllEvents().observeAsState(emptyList())

    val recentBear = allEvents.filter { it.animal == "bear" }.take(3)
    val totalBears = allEvents.count { it.animal == "bear" }

    val statusColor by animateColorAsState(
        targetValue = if (serverRunning) ForestGreenLight else ErrorRed,
        animationSpec = tween(500),
        label = "status_color"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🐻", fontSize = 22.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Bear Detector",
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenLight
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, "Settings", tint = OnSurface)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceDark
                )
            )
        },
        containerColor = NightBlack
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Server Status Card
            item {
                Spacer(Modifier.height(8.dp))
                ServerStatusCard(serverRunning, statusColor, lastLog)
            }

            // Stats Row
            item {
                StatsRow(totalEvents = allEvents.size, bearEvents = totalBears)
            }

            // Recent Bear Detections header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Recent Bear Detections",
                        color = OnSurface,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp
                    )
                    TextButton(onClick = onNavigateToHistory) {
                        Text("View All", color = ForestGreenLight)
                    }
                }
            }

            if (recentBear.isEmpty()) {
                item {
                    EmptyBearCard()
                }
            } else {
                items(recentBear) { event ->
                    DetectionEventCard(event = event)
                }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
fun ServerStatusCard(running: Boolean, statusColor: Color, lastLog: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceContainer),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (running) "Server Running" else "Server Stopped",
                    color = statusColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            if (lastLog.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = lastLog,
                    color = OnSurface.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun StatsRow(totalEvents: Int, bearEvents: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StatCard(
            modifier = Modifier.weight(1f),
            label = "Total Events",
            value = totalEvents.toString(),
            icon = "📷"
        )
        StatCard(
            modifier = Modifier.weight(1f),
            label = "Bear Alerts",
            value = bearEvents.toString(),
            icon = "🐻",
            valueColor = if (bearEvents > 0) AmberAlertLight else OnSurface
        )
    }
}

@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    icon: String,
    valueColor: Color = ForestGreenLight
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = SurfaceContainer),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(icon, fontSize = 28.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = valueColor, fontWeight = FontWeight.Bold, fontSize = 24.sp)
            Text(label, color = OnSurface.copy(alpha = 0.6f), fontSize = 11.sp)
        }
    }
}

@Composable
fun DetectionEventCard(event: DetectionEvent) {
    val isBear = event.animal == "bear"
    val borderColor = if (isBear) AmberAlert else ForestGreenLight
    val emoji = when (event.animal) {
        "bear"  -> "🐻"
        "human" -> "👤"
        "deer"  -> "🦌"
        "dog"   -> "🐕"
        "boar"  -> "🐗"
        "empty" -> "🌿"
        else    -> "❓"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceContainer),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isBear) 1.5.dp else 0.5.dp,
            color = borderColor.copy(alpha = 0.6f)
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(emoji, fontSize = 32.sp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = event.animal.replaceFirstChar { it.uppercase() },
                    color = if (isBear) AmberAlertLight else OnSurface,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = event.description ?: "",
                    color = OnSurface.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
                        .format(Date(event.timestamp)),
                    color = OnSurface.copy(alpha = 0.4f),
                    fontSize = 11.sp
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${event.confidence}%",
                    color = borderColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                if (event.danger) {
                    Text("⚠ Danger", color = ErrorRed, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
fun EmptyBearCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceContainer),
        shape = RoundedCornerShape(12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🌲", fontSize = 40.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "No bears detected yet",
                    color = OnSurface.copy(alpha = 0.5f),
                    fontSize = 14.sp
                )
            }
        }
    }
}
