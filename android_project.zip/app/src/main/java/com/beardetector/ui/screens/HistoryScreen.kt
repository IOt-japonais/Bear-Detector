package com.beardetector.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.beardetector.data.database.DetectionEvent
import com.beardetector.ui.theme.*
import com.beardetector.ui.viewmodel.MainViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: MainViewModel = viewModel(),
    onNavigateBack: () -> Unit
) {
    val allEvents by viewModel.getAllEvents().observeAsState(emptyList())
    var filterBearOnly by remember { mutableStateOf(false) }

    val displayedEvents = if (filterBearOnly) {
        allEvents.filter { it.animal == "bear" }
    } else {
        allEvents
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detection History", color = OnSurface, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = OnSurface)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        },
        containerColor = NightBlack
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            // Filter toggle
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Bears only", color = OnSurface.copy(alpha = 0.7f), fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = filterBearOnly,
                    onCheckedChange = { filterBearOnly = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = AmberAlertLight,
                        checkedTrackColor = AmberAlert.copy(alpha = 0.4f)
                    )
                )
                Spacer(Modifier.weight(1f))
                Text(
                    "${displayedEvents.size} events",
                    color = OnSurface.copy(alpha = 0.4f),
                    fontSize = 13.sp
                )
            }

            Spacer(Modifier.height(8.dp))

            if (displayedEvents.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📋", fontSize = 48.sp)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            if (filterBearOnly) "No bear detections recorded"
                            else "No detections recorded yet",
                            color = OnSurface.copy(alpha = 0.5f)
                        )
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(displayedEvents) { _, event ->
                        HistoryEventCard(
                            event = event,
                            onDelete = { viewModel.deleteEvent(event) }
                        )
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}

@Composable
fun HistoryEventCard(event: DetectionEvent, onDelete: () -> Unit) {
    val isBear = event.animal == "bear"
    var showDeleteDialog by remember { mutableStateOf(false) }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Event", color = OnSurface) },
            text = { Text("Remove this detection from history?", color = OnSurface.copy(alpha = 0.8f)) },
            confirmButton = {
                TextButton(onClick = { onDelete(); showDeleteDialog = false }) {
                    Text("Delete", color = ErrorRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel", color = OnSurface.copy(alpha = 0.6f))
                }
            },
            containerColor = SurfaceContainer
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceContainer),
        shape = RoundedCornerShape(12.dp),
        border = if (isBear) androidx.compose.foundation.BorderStroke(1.dp, AmberAlert.copy(0.5f))
                 else null
    ) {
        Row(modifier = Modifier.padding(12.dp)) {
            // Thumbnail
            val context = LocalContext.current
            val imageFile = event.imagePath?.let { File(it) }
            if (imageFile != null && imageFile.exists()) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(imageFile)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Detection image",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (event.animal) {
                            "bear"  -> "🐻"; "human" -> "👤"; "deer" -> "🦌"
                            "dog"   -> "🐕"; "boar"  -> "🐗"; "empty" -> "🌿"
                            else    -> "❓"
                        },
                        fontSize = 32.sp
                    )
                }
            }

            Spacer(Modifier.width(12.dp))

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = event.animal.replaceFirstChar { it.uppercase() },
                        color = if (isBear) AmberAlertLight else ForestGreenLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    if (event.danger) {
                        Spacer(Modifier.width(6.dp))
                        Text("⚠", fontSize = 13.sp)
                    }
                }
                Text(
                    text = event.description ?: "No description",
                    color = OnSurface.copy(alpha = 0.65f),
                    fontSize = 12.sp,
                    maxLines = 2
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                        .format(Date(event.timestamp)),
                    color = OnSurface.copy(alpha = 0.4f),
                    fontSize = 11.sp
                )
                Text(
                    text = "Diff: %.1f%%".format(event.diffPercentage),
                    color = OnSurface.copy(alpha = 0.35f),
                    fontSize = 10.sp
                )
            }

            // Right column
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${event.confidence}%",
                    color = if (isBear) AmberAlertLight else ForestGreenLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(Modifier.height(8.dp))
                IconButton(
                    onClick = { showDeleteDialog = true },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        Icons.Default.Delete,
                        "Delete",
                        tint = OnSurface.copy(alpha = 0.35f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
