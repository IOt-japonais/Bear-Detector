package com.beardetector.ui.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.beardetector.data.repository.SettingsRepository;

public class SettingsViewModel extends AndroidViewModel {

    private final SettingsRepository settings;

    private final MutableLiveData<String>  apiKey;
    private final MutableLiveData<Integer> autoDeleteDays;
    private final MutableLiveData<String>  saveMessage = new MutableLiveData<>("");

    public SettingsViewModel(Application application) {
        super(application);
        settings = SettingsRepository.getInstance(application);

        apiKey         = new MutableLiveData<>(settings.getAnthropicApiKey());
        autoDeleteDays = new MutableLiveData<>(settings.getAutoDeleteDays());
    }

    public LiveData<String>  getApiKey()        { return apiKey; }
    public LiveData<Integer> getAutoDeleteDays() { return autoDeleteDays; }
    public LiveData<String>  getSaveMessage()   { return saveMessage; }

    public void saveSettings(String key,  int days) {
        settings.setAnthropicApiKey(key.trim());
        settings.setAutoDeleteDays(days);

        apiKey.setValue(key.trim());
        autoDeleteDays.setValue(days);

        saveMessage.setValue("Settings saved ✓");
    }
}
