package com.beardetector.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.beardetector.ui.screens.HistoryScreen
import com.beardetector.ui.screens.HomeScreen
import com.beardetector.ui.screens.SettingsScreen
import com.beardetector.ui.viewmodel.MainViewModel
import com.beardetector.ui.viewmodel.SettingsViewModel

object Destinations {
    const val HOME     = "home"
    const val HISTORY  = "history"
    const val SETTINGS = "settings"
}

@Composable
fun BearDetectorNavGraph(
    navController: NavHostController = rememberNavController(),
    mainViewModel: MainViewModel,
    settingsViewModel: SettingsViewModel,
    onStartServer: () -> Unit,
    onStopServer: () -> Unit
) {
    NavHost(navController = navController, startDestination = Destinations.HOME) {

        composable(Destinations.HOME) {
            HomeScreen(
                viewModel            = mainViewModel,
                onNavigateToHistory  = { navController.navigate(Destinations.HISTORY) },
                onNavigateToSettings = { navController.navigate(Destinations.SETTINGS) }
            )
        }

        composable(Destinations.HISTORY) {
            HistoryScreen(
                viewModel      = mainViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Destinations.SETTINGS) {
            SettingsScreen(
                viewModel      = settingsViewModel,
                onNavigateBack = { navController.popBackStack() },
                onStartServer  = onStartServer,
                onStopServer   = onStopServer
            )
        }
    }
}
