package com.beardetector.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Forest / night-vision palette
val ForestGreen       = Color(0xFF2E7D32)
val ForestGreenLight  = Color(0xFF60AD5E)
val ForestGreenDark   = Color(0xFF005005)
val AmberAlert        = Color(0xFFFF6F00)
val AmberAlertLight   = Color(0xFFFFA040)
val NightBlack        = Color(0xFF0A0A0A)
val SurfaceDark       = Color(0xFF1A1A1A)
val SurfaceContainer  = Color(0xFF252525)
val OnSurface         = Color(0xFFE0E0E0)
val ErrorRed          = Color(0xFFCF6679)

private val DarkColorScheme = darkColorScheme(
    primary          = ForestGreenLight,
    onPrimary        = Color(0xFF003A00),
    primaryContainer = ForestGreenDark,
    secondary        = AmberAlertLight,
    onSecondary      = Color(0xFF3E1F00),
    tertiary         = Color(0xFF80CBC4),
    background       = NightBlack,
    surface          = SurfaceDark,
    surfaceVariant   = SurfaceContainer,
    onBackground     = OnSurface,
    onSurface        = OnSurface,
    error            = ErrorRed
)

@Composable
fun BearDetectorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
