package com.beardetector.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.beardetector.ui.theme.*
import com.beardetector.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = viewModel(),
    onNavigateBack: () -> Unit,
    onStartServer: () -> Unit,
    onStopServer: () -> Unit
) {
    val savedApiKey    by viewModel.getApiKey().observeAsState("")
    val savedDays      by viewModel.getAutoDeleteDays().observeAsState(30)
    val saveMessage    by viewModel.getSaveMessage().observeAsState("")

    var apiKeyInput    by remember(savedApiKey)    { mutableStateOf(savedApiKey ?: "") }
    var daysInput      by remember(savedDays)      { mutableStateOf(savedDays.toString()) }
    var showApiKey     by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", color = OnSurface, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = OnSurface)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        },
        containerColor = NightBlack
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            // --- Server Control ---
            SettingsSection(title = "🖥 Server Control") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onStartServer,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Start", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onStopServer,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Stop", fontWeight = FontWeight.Bold)
                    }
                }
                Text(
                    "Start or stop the HTTP server on port 8080.",
                    color = OnSurface.copy(alpha = 0.4f),
                    fontSize = 12.sp
                )
            }

            // --- Anthropic ---
            SettingsSection(title = "🤖 Anthropic Vision API") {
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    label = { Text("API Key", color = OnSurface.copy(alpha = 0.6f)) },
                    placeholder = { Text("sk-ant-...", color = OnSurface.copy(alpha = 0.3f)) },
                    singleLine = true,
                    visualTransformation = if (showApiKey) VisualTransformation.None
                                           else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showApiKey = !showApiKey }) {
                            Icon(
                                if (showApiKey) Icons.Default.VisibilityOff
                                else Icons.Default.Visibility,
                                contentDescription = "Toggle visibility",
                                tint = OnSurface.copy(alpha = 0.5f)
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    colors = settingsTextFieldColors()
                )
                if (apiKeyInput.isNotBlank()) {
                    Text(
                        "Key entered: ${apiKeyInput.take(7)}…",
                        color = ForestGreenLight,
                        fontSize = 12.sp
                    )
                }
            }


            // --- Storage ---
            SettingsSection(title = "🗂 Storage & Cleanup") {
                OutlinedTextField(
                    value = daysInput,
                    onValueChange = { daysInput = it.filter { c -> c.isDigit() } },
                    label = { Text("Auto-delete images after (days)", color = OnSurface.copy(alpha = 0.6f)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = settingsTextFieldColors()
                )
                Text(
                    "Images older than this will be deleted automatically. Default: 30 days.",
                    color = OnSurface.copy(alpha = 0.4f),
                    fontSize = 12.sp
                )
            }

            // Save Button
            Button(
                onClick = {
                    viewModel.saveSettings(
                        apiKeyInput,
                        (daysInput.toIntOrNull() ?: 30).toFloat().toInt()
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save Settings", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            if (saveMessage.isNotBlank()) {
                Text(
                    saveMessage,
                    color = ForestGreenLight,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceContainer),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, color = OnSurface, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun settingsTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor   = ForestGreenLight,
    unfocusedBorderColor = OnSurface.copy(alpha = 0.3f),
    focusedLabelColor    = ForestGreenLight,
    cursorColor          = ForestGreenLight,
    focusedTextColor     = OnSurface,
    unfocusedTextColor   = OnSurface
)
