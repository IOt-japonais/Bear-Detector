package com.beardetector.ui.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.beardetector.data.database.DetectionEvent;
import com.beardetector.data.repository.DetectionRepository;

import java.util.List;

public class MainViewModel extends AndroidViewModel {

    private final DetectionRepository repository;

    private final MutableLiveData<Boolean> serverRunning  = new MutableLiveData<>(false);
    private final MutableLiveData<String>  lastLogMessage = new MutableLiveData<>("");
    private final MutableLiveData<String>  serverIp       = new MutableLiveData<>("");

    public MainViewModel(Application application) {
        super(application);
        repository = DetectionRepository.getInstance(application);
    }

    public LiveData<List<DetectionEvent>> getAllEvents() {
        return repository.getAllEvents();
    }

    public LiveData<Boolean> isServerRunning()   { return serverRunning; }
    public LiveData<String>  getLastLogMessage() { return lastLogMessage; }
    public LiveData<String>  getServerIp()       { return serverIp; }

    public void setServerRunning(boolean running) {
        serverRunning.postValue(running);
    }

    public void appendLog(String message) {
        lastLogMessage.postValue(message);
    }

    public void setServerIp(String ip) {
        serverIp.postValue(ip);
    }

    public void deleteEvent(DetectionEvent event) {
        repository.delete(event);
    }
}
